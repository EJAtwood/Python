# degrees.py
#   Converts degrees Farhenheit to degrees Celsius
#   Robert Van Cleave
#
#   variable list:
#       input:
#           F float
#       calculated:
#           C float
#   Output:
#       F and C
#
#   Key calculations
#       C = (F-32)* (5/9)
#
# key programming structures and/or algorithms
#
#   sequential code: input, calculate, output
#

F = float(input("Enter degrees F: "))

C = (F-32)* (5/9)

print(str(F) + ' degrees F is ' + str(C) + ' degrees C')
