# tip.py
#   Caculates tip and total given a restaurant bill and tip percentage
#   Robert Van Cleave
#
#   variable list:
#       input:
#           bill, percent: float
#       calculated:
#           tip, total: float
#
#   output: bill, tip, total
#
#   Key calculations
#       tip = bill * (percent / 100.0)
#
# key programming structures and/or algorithms
#
#   sequential code: input, calculate, output
#
print("Enter the bill amount: $", end='')
bill = float(input())

print("Enter the tip percentage (whole numbers, e.g. 15 for 15%: ", end='')
percent = float(input())

tip = bill * (percent / 100.0)
total = bill + tip


print('Bill: $' + str(bill))
print('Tip: $' + str(tip))
print('Total due: $' + str(total))