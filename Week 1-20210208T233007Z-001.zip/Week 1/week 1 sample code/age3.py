# This program says hello and asks for my name.

   # ask for their name
myName = input("What is your name?") #ask for AND input all in one statement
print('It is good to meet you, ' + myName)
print('The length of your name is:')
print(len(myName))
myAge = int(input('What is your age?')) # myAge is a int, because the input string was converted to an int before assignment
print('You will be ' + str(myAge + 1) + ' in a year.')