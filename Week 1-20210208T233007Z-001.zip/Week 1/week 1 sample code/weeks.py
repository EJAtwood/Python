# weeks.py
#
#   Robert Van Cleave
#
#   requirements:
#       Calculates weeks and days given total days
#
#   variable list:
#       input:
#           days int
#       calculated:
#           weeks, days, int
#
#   output:
#       weeks, days
#
#   Key calculations
#       Use integer division and remainder to calc weeks and reset days
#
# key programming structures and/or algorithms
#
#   sequential code: input, calculate, output
#
#

print("Enter the total number of days: ", end='')
days = int(input())

weeks = days // 7
days = days % 7


print('Weeks: ' + str(weeks))
print('Days: ' + str(days))
