#
# seconds.py
#   Rob Van Cleave
#
# requirements: given seconds, determine hours, minutes and seconds
#
# variables used:
#   input
#       int seconds
#   calculated:
#       int hours, leftOver, minutes, secondsLeft
#
# output:
#       seconds, hours, minutes, secondsLeft
#
# key calculations:
#       use integer division and modulus
#       there are 3600 seconds in an hours
#       there are 60 seconds in a minute
#
# key programming structures:
#   simple sequence with 3 calculations using leftOver
#
seconds = int(input('Enter the total # of seconds: '))

hours = seconds // 3600
leftOver = seconds % 3600

minutes = leftOver // 60
leftOver = leftOver % 60

secondsLeft = leftOver

print('Initial seconds: ' + str(seconds))
print('Which breaks down into:')
print('   ' + str(hours) + ' hours')
print('   ' + str(minutes) + ' minutes')
print('   ' + str(secondsLeft) + ' seconds')