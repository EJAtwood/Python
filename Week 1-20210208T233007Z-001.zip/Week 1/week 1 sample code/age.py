'''
Name: Ethan Atwood
Description: takes user input for a dollar and cent amount and sets
two variables to those inputs
Variables:
    input:
            amountIn
    output:
            dollars
            cents
Key Calculations:

'''