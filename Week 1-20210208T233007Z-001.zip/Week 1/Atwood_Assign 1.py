'''
Name: Ethan Atwood
File Name: Atwood_Assignment 1
Description: Based on user input, calulate the number of each denominations needed to
create the dollar and cent amount determined by the user.
Variables:
    input:
            amountIn #taken as float input
    output: vars determined from calculations
            dollars #var for int conversion
            oneD
            fiveD
            tenD
            twentyD
            fiftyD
            oneHundredD
            cents #var for int conversion
            oneC
            fiveC
            tenC
            twentyFiveC
Key Calculations:
    dollars // x = dollar amounts
    dollars % x = dollar remainder
    cents // x = cent amounts
    cents % x = cent remainder
    dollars = amountIn
    cents = amountIn - dollars * 100
    round off error = cents + 0.49
Algorithms:
    // used to determine initial amount (in dollar or cents) and %
    used to determine remainders. Cycle through this logic for each denomination
    for determining the amount of denominations per the user input amount.

'''

print('Please enter a dollar and cent amount (for example 22.63): ') #prompts user
amountIn = float(input()) #takes in user amount as float type

#################dollar and cent integer calculations#################
# converts amountIn to interger for dollars and cents
#
dollars = int(amountIn) #dollar integer conversion left alone from Lab 1
cents = int(((amountIn - dollars) * 100) + 0.49) #calculates int cents from dollars and accounts for roundoff error

#################Dollar calculations#################
# determines for each denomination the numberand
# remainder of dollars left
#
oneHundredD = dollars // 100
remainder = dollars % 100

fiftyD = remainder // 50
remainder = remainder % 50

twentyD = remainder // 20
remainder = remainder % 20

tenD = remainder // 10
remainder = remainder % 10

fiveD = remainder // 5
remainder = remainder % 5

oneD = remainder // 1
remainder = remainder % 1


#################cent calulations#################
# determines for each denomination the numberand
# remainder of cents left
#
twentyFiveC = cents // 25
remainder = cents % 25

tenC = remainder // 10
remainder = remainder % 10

fiveC = remainder // 5
remainder = remainder % 5

oneC = remainder // 1
remainder = remainder % 1


#################Print Statements#################
# prints each denomination and amount
#
print('One hundred dollar bills: ' + str(oneHundredD),
'\nFifty dollar bills: ' + str(fiftyD),
'\nTwenty dollar bills: ' + str(twentyD),
'\nTen dollar bills: ' + str(tenD),
'\nFive dollar bills: ' + str(fiveD),
'\nOne dollar bills: ' + str(oneD),
'\nQuarters: ' + str(twentyFiveC),
'\nDimes: ' + str(tenC),
'\nNickles: ' + str(fiveC),
'\nPennies: ' + str(oneC)
)









