'''
Name: Ethan Atwood
File Name: Atwood_Lab 1
Description: takes user input for a dollar and cent amount and prints those dollars and cent
amounts in an integer representation
Variables:
    input:
            amountIn
    output:
            dollars
            cents
Key Calculations:
    dollars = amountIn
    cents = amountIn - dollars * 100
    round off error = cents + 0.49
Algorithms:
    N/A
'''

print('Please enter a dollar and cent amount (for example 22.63): ') #prompts user

amountIn = float(input()) #takes in user amount as float type

dollars = int(amountIn) # calculates dollar with int conversion
print('Dollars: ' + str(dollars)) #outputs dollar amount

cents = int(((amountIn - dollars) * 100) + 0.49) #calculates cents from dollars and accounts for roundoff error
print('Cents: ' + str(cents)) #outputs cent amount
