# area.py
# Robert van Cleave
#
# this script inputs the radius of a circle,
# and determines the area
#
# variables:
#   input (float) radius
#   calculated: (float) area
#
# Output area
#
# key calculations: area = PI*r*r
#
#
# test data:    radius = 1.0, area = pi
#               radius = 5.64, area = 99.93
#
#

import math

print('This script will calulate the radius of a circle given the area')

print('Enter the radius: ',end='')
radius = float(input())

area = math.pi * radius**2


print("The area of the circle is: " + str(area))