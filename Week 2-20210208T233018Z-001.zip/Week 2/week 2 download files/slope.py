# slope.py
# Robert van Cleave
#
# this script inputs two points and dermines the slope of the connecting line
#
# variables:
#    input (float) x1, y1, x2, y2
#   calculated: (float) slope
#
# output: slope (rounded to 2 places)
#
# key calculations: slope = (y2-y1)/(x2-x1)
#
#
# test data:    1.0 2.0 3.0 4.0 slope = 1.0
#               1.0 2.0 3.0 2.0 slope = 0.0
#               1.0 2.0 1.0 3.0 slope = undefined
#
print('This script will calulate the slope of a line connecting two points')

x1 = float(input('Enter the X coordinate of the first point: '))
y1 = float(input('Enter the Y coordinate of the first point: '))
x2 = float(input('Enter the X coordinate of the second point: '))
y2 = float(input('Enter the Y coordinate of the second point: '))

slope = (y2-y1) / (x2-x1)

print("The slope of the connecting line is: %1.3f"%slope)