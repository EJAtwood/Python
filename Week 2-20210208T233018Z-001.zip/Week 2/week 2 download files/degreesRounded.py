# degreesRounded.py
#   Converts degrees Farhenheit to degrees Celsius
#   Robert Van Cleave
#
#   variable list:
#       input: F
#       output: C
#
#   Key calculations
#       C = (F-32)* (5/9)
#

print("Enter degrees F: ")
F = float(input())

C = (F-32)* (5/9)

print(str(F) + ' degrees F is ' + str(round(C,3)) + ' degrees C')
