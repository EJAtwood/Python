# slope2.py
# Robert van Cleave
#
# this script inputs two points and dermines the slope of the connecting line
#
# variables:
#    input (float) x1, y1, x2, y2
#   calculated: (float) deltaX, deltaY, slope
#
# output: (float) slope
#
# key calculations:
#           deltaX and deltaY are the change in x and y respectively
#           slope = deltaY/deltaX
#
#
# test data:    1.0 2.0 3.0 4.0 slope = 1.0
#               1.0 2.0 3.0 2.0 slope = 0.0
#               1.0 2.0 1.0 3.0 slope = undefined
#
print('This script will calulate the slope of a line connecting two points')
x1 = float(input('Enter the X coordinate of the first point: '))
y1 = float(input('Enter the Y coordinate of the first point: '))
x2 = float(input('Enter the X coordinate of the second point: '))
y2 = float(input('Enter the Y coordinate of the second point: '))


deltaX = x2-x1
deltaY = y2-y1
slope = deltaY / deltaX

print("The slope of the connecting line is: %1.2f"%(slope))