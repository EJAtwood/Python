# sampleIfElse.py
#
# Rob Van Cleave
#
# Requirements:
# Given a sales amount:
#    Calculate total due with 6% tax.
#    10% discount for all orders $100 or more
#
# Variables
#   input: amount (float)
#   calculated: discount, subtotal, tax, total (float)
#
# Output: amount, discount, subtotal, tax, and total
# 		
#
#
# Key calculations
#
# calculate discount: if amount >= 100 discount is 10%,
#                       else discount is 0.0
#
# Test data:
#
# amount	discount	subtotal	tax	total
# 99.99		0		99.99		6.00	105.99
# 100.00	10		90.00		5.40	95.40
#
# Note: this version uses %.2f for rounding and decimals
#
# See separate document on this technique
#


print("Enter the sales amount: $",end='')
amount = float(input())


if amount >=100.0:
    discount = amount * 0.10
else:
    discount = 0.0


subtotal = amount - discount
tax = subtotal * 0.06
total = subtotal + tax

print("Amount of Sale: $%.2f" % amount)
print("      Discount: $%.2f" % discount)
print("      Subtotal: $%.2f" % subtotal)
print("           Tax: $%.2f" % tax)
print("     Total Due: $%.2f" % total)