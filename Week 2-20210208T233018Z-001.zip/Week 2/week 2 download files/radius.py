# radius.py
# Robert van Cleave
#
# this script inputs the area of a circle, and determines the radius
# variables:
#   input (float) area
#   calculated: (float) radius
#
# Output radius
#
# key calculations: radius = square root of area/ PI
#
#
# test data:    area = 10, radius = 1.78
#               area = 100, radius = 5.64
#
#

import math

print('This script will calulate the radius of a circle given the area')

print('Enter the area: ',end='')
area = float(input())

radius = math.sqrt(area/3.1416)


print("The radius of the circle is: %1.2f"%radius)