# degreesRoundedBetter.py
#   Converts degrees Farhenheit to degrees Celsius
#   Robert Van Cleave
#
#   variable list:
#       input: F
#       output: C
#
#   Key calculations
#       C = (F-32)* (5/9)
#

print("Enter degrees F: ")
F = float(input())

C = (F-32)* (5/9)

# three print statements
# first, no rounding
print(str(F) + ' degrees F is ' + str(C) + ' degrees C')
# now with round
print(str(F) + ' degrees F is ' + str(round(C,3)) + ' degrees C')
# now with formatted output
print('%1.2f degrees F is %1.3f degrees C'%(F,C))
