# formattedOutput.py
#
#   refer to the document "Using Formatted Output.pdf"
#       enter 67.99 for the amout to get exactly the example in the document
#
#   Rob Van Cleave
#
# given a sales amount calculate 6% tax
#
# variables
#   input amount (float)
#   calculated tax (float)
#
# output:
#   amount and tax formatted to two decimal places
#
# key calculations: tax is 6% of amount
#
amount = float(input("Enter the sales amount: $"))
tax = amount * 0.06
#   output #1
print('The amount is $%1.2f, and the tax is $%1.2f'%(amount,tax))
#   output #2
print('The amount is $%10.2f, and the tax is $%10.2f'%(amount,tax))
print('The actual value in the variable tax is ' + str(tax))