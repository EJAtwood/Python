'''
Name: Ethan Atwood
File Name: Atwood_Lab 2_Part 2
Description: Takes a salesman's car sales per month and calculates their
commission based on the amount of cars they sold
    input:
       int carSold
    output:
        commission
Key Calculations:
    carSold * 500
Algorithms:
   if (carSold >= 15) then cars * 500
   else $300
'''

carSold = int(input("How many cars did you sell this month?: ")) #inputs number of cars sold

###################If Statement###################
# If the salesman sells 15 or more cars, they get $500
# for each car sold, otherwise they get carSold * $300
#
if (carSold >= 15):
    commission = (carSold * 500)
    print('Your commision for the month is $%1.2f' %commission) #formatted to two places
    #print('Your commision for the month is $' + str(round(commission,2))) #formatted to two places

else:
    commission = (carSold * 300)
    print('Your commission for the month is $%1.2f' %commission) #anything under 15 sold = $300