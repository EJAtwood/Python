'''
Name: Ethan Atwood
File Name: Atwood_Assignment 2_Part 1
Description: Takes user input for hours worked and at what wage and
determines the gross pay, including overtime pay.
    input:
        float hoursWorked
        float otHoursWorked
        float rate
        float otWage
    output:
        grossPay
        otPay
Key Calculations:
    grossPay = hoursWorked * 40
    otHoursWorked = hoursWorked - 40
    otWage = (40 * rate) + (otHoursWorked * (rate *1.5))
Algorithms:
    if hoursWorked <= 40 then normal wage for those hours
    if hours > 40 then first 40 are at the normal rate and
    the otHoursWorked are at 1.5 the normal rate
'''

###################user Input###################
# Takes user input for hours worked and at what wage
# and rounds whatever input they type in to only 2 decimals
#
hoursWorked = round(float(input('Please enter the number of hours worked in a week (in hours): ')), 2)
rate = round(float(input('Please enter the hourly wage for the hours worked: ' )), 2)
#print(hoursWorked) #debugging statements for ensuring roundoff of user input to only two decimals for calculations
#print(rate)

###################If Else Statements###################
# If the employee worked less than 40 hours then their wage
# is 40 * their normal wage. If they worked more than 40, their
# wage is their normal rate for the first 40 hours, and then
# any hours over 40 is multiplied by their rate times 1.5.
#
if (hoursWorked <= 40):
    grossPay = (hoursWorked * rate) #calculate gross pay
    print('Your gross pay is $%1.2f ' %grossPay)

else:
    otHoursWorked = (hoursWorked - 40)
    otWage = (40 * rate) + (otHoursWorked * (rate *1.5)) #calc gross + ot pay
    print('Your wages including overtime are: $%1.2f' %otWage)
