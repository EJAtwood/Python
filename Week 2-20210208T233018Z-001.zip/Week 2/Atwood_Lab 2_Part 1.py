'''
Name: Ethan Atwood
File Name: Atwood_Lab 2_Part 1
Description: Takes user input for two sets of coordinates and calculates the
distance between them.
    input:
        x1
        x2
        y1
        y2
    output:
        distance
Key Calculations:
    distance = sqrt((deltax)**2 + (deltay)**2)
Algorithms:
   N/A
'''
import math #needed library for sqrt() function

###################User Input###################
# Takes in user input for each coordinate
#
x1 = float(input('Please enter the first x cordinate: '))
y1 = float(input('Please enter the first y cordinate: '))
x2 = float(input('Please enter the second x cordinate: '))
y2 = float(input('Please enter the second y cordinate: '))

###################Distance Calculation###################
# Takes user coordinates, calculates, and prints distance
#
distance = math.sqrt((x2-x1)**2 + ((y2-y1)**2))
print('Your coordinates are: ('+ str(x1) + ',' + str(y1) + ') and (' + str(x2) + ',' + str(y2) + ')' )
print("The distance between those coordinates is: %1.2f" %distance)#formatted to two decimal points


