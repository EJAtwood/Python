'''
Name: Ethan Atwood
File Name: Atwood_Lab 2_Part 2
Description: Take user input for two cartesian points with a radius, that indicate
two points of two circles, and determine if the circles intersect.
    input:
        float x1, x2, y1, y2
        double radius1, radius2 (double in python is similar to float)
    output:
        distance
        radiiSum
Key Calculations:
    distance = sqrt((deltax)**2 + (deltay)**2)
    radiiSum = radius1 + radius2
Algorithms:
   if the sum of the radiis are less than the distance
   between the two cartesian points, the circles will not
   intersect, else they do
'''
import math #needed library for sqrt() function

###################User Input###################
# Takes in user input for each coordinate (center point)
# and radius value
#
x1 = float(input('Please enter the first x cordinate: '))
y1 = float(input('Please enter the first y cordinate: '))
radius1 = float(input('Please enter the first radius value: '))
x2 = float(input('Please enter the second x cordinate: '))
y2 = float(input('Please enter the second y cordinate: '))
radius2 = float(input('Please enter the second radius value: '))

###################Calculations###################
# The distance between two points and the sum of the
# radiis are calcualted and displayed.
#
distance = math.sqrt((x2-x1)**2 + ((y2-y1)**2)) #calcs distance
radiiSum = radius1 + radius2 #sums radii
print('Your coordinates are: ('+ str(x1) + ',' + str(y1) + ') and (' + str(x2) + ',' + str(y2) + ')' + ' and your radiis are '
+  str(radius1) + ' and ' + str(radius2) + ', respectively.')
print("The distance between those coordinates is: %1.2f" %distance)#formatted to two decimal points
print("The sum of the radii are: %1.2f" %radiiSum)#formatted to two decimal points

###################If Else Statement###################
# Logic for determining in the two circles intersect
# depends on the above calculations. If raddiSum is less
# then the distance, they dont touch, elseif they do, and
# else, something went wrong with the calc or number entry
#
if(radiiSum < distance):
    print('The two circles do no intersect.')
elif(radiiSum >= distance):
    print('The two circles intersect.')
else:
    print('debugging statement, something went wrong') #debug statement for self code testing




