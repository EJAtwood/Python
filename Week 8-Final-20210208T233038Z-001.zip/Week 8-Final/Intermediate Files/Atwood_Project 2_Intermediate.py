'''
Name: Ethan Atwood
Date: 7/20/2020
File Name: Atwood_Project 2 Intermediate
Description: Opens and reads a network Scan.txt for
Nmap IP addresses (nodes). It then takes those individual IP
addresses, formats them in a clean way with slice(), and
writes them to ipLog.txt for viewing. Amount of nodes is printed
to the console.

'''

############## ipStrip##############
# Takes a parameter that is just a raw element including ( ) that
# gets stripped to its dot decimal version without ( ). That ip address
# is returned in the right fomrat to checkLine()
#
def ipStrip(ip):
    #print(ip)
    isIpParenth = ip.startswith('(') #bool for seeing if line starts with '('

    if(isIpParenth): #if true strip with a slice
        ipAddress = slice(1,-1) #stripping down the parentheses at the begining and end of the IP element
        #print(ip[ipAddress]) debugg to see proper stripping with slice()
        return ip[ipAddress] #strips down IP to just the octet info and returns value

    else:
        return ip #returned as is with no stripping
        #print(ip)


############## checkLine ##############
# takes in the parameter, which is a single line from the Scan.txt file.
# It splits it into an array of items, and then if that array has anything
# in it(items > 0), it will check the first element in that array for the
# 'Nmap' string and if T, will return stripped IP value.
#
def checkLine(line):
    items = line.split() #splits the line into an array of elements
    ipLogWrite = open("ipLog.txt", 'w') #opens write file
    #print(items)

    if len(items) > 0: #if there is anything in the array do something
        if(items[0] == 'Nmap'): #if the 0 element is Nmap, return True
            #ipStrip(items[-1])
            #print(items[-1])
            #ipLogWrite.write()
            return ipStrip(items[-1]) #send the last element of each line to ipStrip and returns it to LogsIp function
        else: #if not, return NO
            return 'NO'
    else:
        return "blank" #debug statement
    ipLogWrite.close() #closes write file


############## logIPs ##############
# Takes in the lines of info from main, initializes a counter
# and runs a for loops for incrementing through each line.
# It passes it to checkLine then gets back a IP or NO vlaue. Depending on value,
# it will write the file the appropriate IP value.
#
def logIPs(lineList):
    count = 0 #initializes counter
    ipLogWrite = open("ipLog.txt", 'w') #opens write file
    for i in range(len(lineList)): #loops through each line
        line = checkLine(lineList[i]) #calls the checkLine function which returns a bool

        #print(line)
        if(line != 'NO'): #if return value line != NO it will print to logfile
            if not lineList[i].strip(): #strips end line for proper couting and file output
                ipLogWrite.write('\n') #prints to the file in a nice format
                continue
            ipLogWrite.write(line) #write all IPs to file without ( )s
            count = count + 1 #increments counter
            #print(lineList[i], end='')
        else: #if line is == 'NO' (or anything else), it should not print to log file and just be ignored
            False

    ipLogWrite.close() #closes write file
    return count #returns counter to main for console printing


############## main ##############
# opens to read the scan.txt, and reads all lines. The lines are
# passed to logIPs for checking, writing to file, and to return
# a counter for number of nodes. A message is printed to screen
# and dataFile closed.
#
def main():
    dataFile = open("Scan.txt", 'r') #opens file
    lineList = dataFile.readlines() #reads lines into variable
    #print(lineList)
    print(str(logIPs(lineList)) + ' nodes scanned') #calls the logsIP function and passes the list argument
    print('Please see ipLog.txt for IP Addresses...') #clean print statement
    dataFile.close() #always close


main() #call mainto run program