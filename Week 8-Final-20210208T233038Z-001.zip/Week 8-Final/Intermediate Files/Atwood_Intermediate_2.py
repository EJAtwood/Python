'''
Sucessfully prints IPs without parentheses to console
Name: Ethan Atwood
Date: 7/20/2020
File Name: Atwood_Project 2 Intermediate 1
Description: Opens and reads a network Scan.txt for
Nmap IP addresses (nodes). It prints the node IP to an
output file called ipLogs.txt and prints the number of nodes to the console

'''
############## checkLine ##############
# takes in the parameter, which is a single line from the Scan.txt file.
# It splits it into an array of items, and then if that array has anything
# in it(items > 0), it will check the first element in that array for the
# 'Nmap' string and return True if it does. False otherwise.
#
def ipStrip(ip):
    #print(ip)

    isIpParenth = ip.startswith('(')

    if(isIpParenth):
        ipAddress = slice(1,-1) #stripping down the parentheses at the begining and end of the IP element
        print(ip[ipAddress])
    else:
        print(ip)

############## checkLine ##############
# takes in the parameter, which is a single line from the Scan.txt file.
# It splits it into an array of items, and then if that array has anything
# in it(items > 0), it will check the first element in that array for the
# 'Nmap' string and return True if it does. False otherwise.
#
def checkLine(line):
    items = line.split() #splits the line into an array of elements
    #print(items)

    if len(items) > 0: #if there is anything in the array do something
        if(items[0] == 'Nmap'): #if the 0 element is Nmap, return True
            ipStrip(items[-1]) #send the last element of each line to ipStrip :)
            return True
        else: #if not, return bool False
            return False
    else:
        return "blank" #test statement


############## logIPs ##############
# takes in the lines of info from main, initializes a counter
# cand runs a for loops for incrementing through each line.
# it passes it to checkLine then gets back a bool. Depending on bool,
# it will strip the end line flag, write the node to ipLog.txt, and
# increments the counter.
#
def logIPs(lineList):
    count = 0 #initializes counter
    ipLogWrite = open("ipLog.txt", 'w') #opens write file
    for i in range(len(lineList)): #loops through each line
        line = checkLine(lineList[i]) #calls the checkLine function which returns a bool
        #print(line)
        if(line): #if bool true
            if not lineList[i].strip(): #strips end line for proper couting and file output
                continue
            ipLogWrite.write( lineList[i]) #write to file
            count = count + 1 #increments counter
            #print(lineList[i], end='')
        else:
            False
    return count #returns counter to main for printing
    ipLogWrite.close() #closes write file
    #print(count)


############## main ##############
# opens to read the scan.txt, and reads all lines. The lines are
# passed to logIPs for checking, writing to file, and to return
# a counter for number of nodes. A message is printed to screen
# and dataFile closed.
#
def main():
    dataFile = open("Scan.txt", 'r') #opens file
    lineList = dataFile.readlines() #reads lines into variable
    #print(lineList)
    print(str(logIPs(lineList)) + ' nodes scanned.') #calls the logsIP function and passes the list argument
    print('Please see ipLog.txt for node IP information...') #clean print statement
    dataFile.close() #always close

main()