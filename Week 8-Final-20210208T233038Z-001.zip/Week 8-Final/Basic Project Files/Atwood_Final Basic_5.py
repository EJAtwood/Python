'''
Prints Nmap info and counts...but counts all end lines/returns too
Name: Ethan Atwood
Date: 7/14/2020
File Name: Atwood_Final Basic
Description:

'''
def checkLine(line):
    items = line.split()
    #print(items)
    if len(items) > 0:
        if(items[0] == 'Nmap'):
            return True
        else:
            return False
    else:
        return "blank"


def logIPs(lineList):
    count = 0
    ipLogWrite = open("ipLog.txt", 'w')

    for i in range(len(lineList)):
        line = checkLine(lineList[i])
        #print(line)
        if(line):
            if not lineList[i].strip():
                continue
            ipLogWrite.write( lineList[i])
            count = count + 1
            #print(lineList[i], end='')
    return count
    ipLogWrite.close()
    #print(count)


def main():
    dataFile = open("Scan.txt", 'r') #open file
    lineList = dataFile.readlines()
    #print(lineList)
    print(logIPs(lineList))
    dataFile.close()

main()