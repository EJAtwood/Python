'''
RETURNS first word of each line for comparison
Name: Ethan Atwood
Date: 7/14/2020
File Name: Atwood_Final Basic
Description:

'''
def checkLine(line):
    #print(line)
    items = line.split()
    #print(len(items))
    if len(items) > 0:
        print(items[0])
        #if(items[0]== 'Nmap'):
        #    return 'Yes'

    '''if len(items) > 0:
        if(items[0] == "Nmap"):
            return True
    else:
        return False'''

def logIPs(lineList):
    count = 0
    ipLogWrite = open("ipLog.txt", 'w')
    #print(len(lineList))
    #print(lineList[1])
    #print(lineList)

    for i in range(len(lineList)):
        #print(lineList[i], end='') #prints the exact same file but to the console
        #print( str(i + 1) + '. ' + lineList[i])
        checkLine(lineList[i])

        #if(checkLine(lineList[i])):
        #    ipLogWrite.write(lineList[i])
        #    count =+ 1
        #    return count

    #print(count)

    '''for i in range(0, len(lineList)):
        #print(lineList[i])
        #line = lineList[i]
        #print(len(lineList))
        #print(lineList[i])
        line = checkLine(lineList[i])
        #print(line)

        if(line):
            count = count + 1
            ipLogWrite.write(lineList[i])
        else:
            return "abc"

        #if(checkLine(lineList[i])):
        #print(lineList[i])
        #    count = count + 1
        #    ipLogWrite.write(lineList[i])
        #else:
        #    return "abc"

    #return count'''

def main():
    dataFile = open("Scan.txt", 'r') #open file
    lineList = dataFile.readlines()
    #print(lineList)
    print(logIPs(lineList))
    dataFile.close()

main()