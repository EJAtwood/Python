'''
Name: Ethan Atwood
Date: 7/14/2020
File Name: Atwood_Final Basic
Description:

'''
def checkLine(line):
    #print(line)
    items = line.split()
    print(len(items))
    if len(items) > 0:
        if(items[0] == 'Nmap'):
            return True
    else:
        return False

def logIPs(lineList):
    count = 0
    ipLogWrite = open("ipLog.txt", 'w')
    #print(len(lineList))
    for i in range(len(lineList)):
        if(checkLine(lineList[i])):
            count = count + 1
            ipLogWrite.write(lineList[i])
            return count
        else:
            return "abc"


def main():
    dataFile = open("Scan.txt", 'r') #open file
    lineList = dataFile.readlines()
    #print(lineList)
    print(logIPs(lineList))

    dataFile.close()

main()