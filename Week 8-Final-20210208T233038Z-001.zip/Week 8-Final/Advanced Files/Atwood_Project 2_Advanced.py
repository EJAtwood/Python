'''
Name: Ethan Atwood
Date: 7/23/2020
File Name: Atwood_Project 2 Advanced
Description: Takes the Scan.txt file and prints the total service names
that are open and their occurence. It does not print duplicates.

'''

############## countOpen ##############
# takes the services and runs a paralle list count on them.
# They them then are displayed
#
def countOpen(openList):
    dataOut = open("Ports.txt", 'w') #open write
    dataOut.write("Nmap Scan - Current open ports and their occurences \n")

    service = [] #first list
    count = [] #count list

    for i in range(len(openList)): #loops through services
        #print(type(openList[i]))
        try:
            i = service.index(openList[i]) #if service in list already count it
            count[i]+= 1

        except Exception as err: #if service not in list, add and and count it
            service.append(openList[i])
            count.append(1)
            #print(service[i]) debug

    for i in range(len(service)): #loop through and count services and occurences
        dataOut.write(service[i] + ' ' + str(count[i]) + '\n')
        #print(service[i] + ' ' + str(count[i])) debug

    print('Check Ports.txt for output...')

############## getPorts ##############
# takes in the lines from Scan.txt and loops through those lines.
# It checks the lines for a digit, if there is an 'open' and then
# appends the open service name to a list. It passes the service to
# countOpen to then count the occurences
#
def getPorts(entireList):
    openPorts = []

    for i in range(len(entireList)): #loops list

        line = entireList[i] #var for indiviudal line of list

        if not (line[0].isdigit()): #if not a digit, skip line
            continue

        lineItems = line.split() #split line with digit

        if(lineItems[1] == 'open'): #if 1sst element 'open', append service ele 2 to list
            openPorts.append(lineItems[2])

    countOpen(openPorts) #pass the services on for counting
    #print(openPorts)


############## main ##############
# Opens Scan.txt and passes the lines to getPorts function.
#
def main():
    dataFile = open("Scan.txt", 'r') #opens file

    entireList = dataFile.readlines() #reads lines into string
    getPorts(entireList) #pass string to checkPort

    dataFile.close()


main()