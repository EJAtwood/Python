'''
Will print only services with no blanks!
Name: Ethan Atwood
Date: 7/20/2020
File Name: Atwood_Project 2 Advanced
Description:

'''
'''def onlyOpen(word):
    while word.read() != 'NONE':
        newWord = input('Enter a word ("stop" to end): ')
        try:  #must use a try to search for the new word, it bombs if not found
            i = words.index(newWord) # returns the index of the newWord in words
            counts[i] += 1 # the word is there, so we up the count. This will
                       # not be executed if not found
        except Exception as err: # if the newWord is not found, we will add it
            words.append(newWord) # same as words = words + [newWord]
            counts.append(1) # adds a 1 onto the end of counts for this newWord'''

def countOpen(openList):
    #print(openList)
    service = []
    counts = []
    for i in range(len(openList)):
        try:
            i = service.index(openList)
            #service.append(openList)
            #counts[i] += 1
            #print(openList)

        except Exception as err:
            counts.append(1)
            print(openList)
            #return openList


def onlyOpen(word):
    serviceList = []
    workingList = []
    sshCount = 0
    telnetCount = 0
    lineBreak = word.split()
    #print(lineBreak[1]) #prints whether port is open or not!
    #print(lineBreak[0])
    if(lineBreak[1] == 'open'):
        serviceList.append(lineBreak[2])

    #print(serviceList)
    countOpen(serviceList)


def sortPort(line): #sorts lines into just those with open ports
    if(line[0].isdigit()):
        #print(line)
        onlyOpen(line)


def checkPort(portList):
    for i in range(len(portList)):
        items = portList[i]
        sortPort(items)



def main():
    dataFile = open("Scan.txt", 'r') #opens file
    dataOut = open("Ports.txt", 'w')

    portList = dataFile.readlines() #reads lines into variable
    checkPort(portList)

    dataFile.close()
    dataOut.close()

main()