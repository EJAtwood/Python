'''
Name: Ethan Atwood
Date: 7/20/2020
File Name: Atwood_Project 2 Advanced
Description:

'''


#suppose to take list of only open ports and count their occurence and output to file
def countOpen(openList):
    dataOut = open("Ports.txt", 'w')

    service = []
    count = []
    #print(openList) #will print all services (even blank) with brackets

    #for i in range(len(openList)): #prints services (without blanks with no
    #    print(openList[i])


    for i in range(len(openList)): #prints services (without blanks with no
        try:
            service.append(openList[i])
            i = service.index(openList[i])
            count[i]+= 1

        except Exception as err:
            service.append(openList[i])
            count.append(1)
            print(service[i])



#breaks all ports into those that are just open and appends those open services to a list
def onlyOpen(word):
    serviceList = []
    workingList = []
    sshCount = 0
    telnetCount = 0
    lineBreak = word.split()
    #print(lineBreak[1]) #prints whether port is open or not!
    #print(lineBreak[0])
    if(lineBreak[1] == 'open'):
        serviceList.append(lineBreak[2])

    #print(serviceList)
    countOpen(serviceList) #sends list of only open ports on


# sorts all lines into just port numbers and servieces
def sortPort(line): #sorts lines into just those with open ports
    if(line[0].isdigit()):
        #print(line)
        onlyOpen(line) #passes ports/services on


#sorts string into individual lines
def checkPort(portList):
    for i in range(len(portList)):
        items = portList[i]
        sortPort(items) #pass individual lines to sortPort



def main():
    dataFile = open("Scan.txt", 'r') #opens file

    portList = dataFile.readlines() #reads lines into string
    checkPort(portList) #pass string to checkPort

    dataFile.close()


main()