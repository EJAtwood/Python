'''
Will print only services with no blanks and no brackets
Name: Ethan Atwood
Date: 7/20/2020
File Name: Atwood_Project 2 Advanced
Description:

'''




def countOpen(openList):
    #print(openList)
    #print(len(openList))

    #for i in range(len(openList)):
    #    items = openList[i].split() #splits individual lines into strings
    #    print(items[0])

    service = []
    count = []

    for i in range(len(openList)):
        newWord = openList[i].split() #splits individual lines into strings
        try:
            i = service.index(newWord[0])
            count[i] += 1

        except Exception as err:
            service.append(newWord[0])
            count.append(1)


        print(str(service[i]) + ' ' + str(count[i]))



'''#prints only open services with no blanks!
def countOpen(openList):
    #print(openList)
    #print(len(openList))
    for i in range(len(openList)):
        print(openList)'''




def onlyOpen(word):
    serviceList = []
    workingList = []
    sshCount = 0
    telnetCount = 0
    lineBreak = word.split()
    #print(lineBreak[1]) #prints whether port is open or not!
    #print(lineBreak[0])
    if(lineBreak[1] == 'open'):
        serviceList.append(lineBreak[2])

    #print(serviceList)
    countOpen(serviceList)


def sortPort(line): #sorts lines into just those with open ports
    if(line[0].isdigit()):
        #print(line)
        onlyOpen(line)


def checkPort(portList):
    for i in range(len(portList)):
        items = portList[i]
        sortPort(items)



def main():
    dataFile = open("Scan.txt", 'r') #opens file
    dataOut = open("Ports.txt", 'w')

    portList = dataFile.readlines() #reads lines into variable
    checkPort(portList)

    dataFile.close()
    dataOut.close()

main()