'''
can Print the list of services if port is open
Name: Ethan Atwood
Date: 7/20/2020
File Name: Atwood_Project 2 Advanced
Description:

'''


def onlyOpen(word):
    serviceList = []
    lineBreak = word.split()
    #print(lineBreak[1]) #prints whether port is open or not!
    #print(lineBreak[0])
    if(lineBreak[1] == 'open'):
        serviceList.append(str(lineBreak[2]))
    print(serviceList)

def sortPort(line): #sorts lines into just those with open ports
    if(line[0].isdigit()):
        #print(line)
        onlyOpen(line)

def checkPort(portList):
    for i in range(len(portList)):
        items = portList[i]
        sortPort(items)


def main():
    dataFile = open("Scan.txt", 'r') #opens file
    dataOut = open("Ports.txt", 'w')

    portList = dataFile.readlines() #reads lines into variable
    checkPort(portList)

    dataFile.close()
    dataOut.close()

main()