'''
WORKING wkHourList conversion
Name: Ethan Atwood
Date: 7/14/2020
File Name: Atwood_
Description:

'''
##############checkItems##############
# converts table data to ints and floats if possible.
# and returns true if it can. Otherwise the data returns
# false and the data is wrong in the table somewhere
#
def checkItems(a,x,b):
    try:
        int(a)
        float(x)
        int(b)
        return True
    except Exception as err:
        return False


##############convertHours##############
#
#
def convertHours(wkHours, wkHoursList):
    item = wkHours.split()
    try:
        item[0] = int(item[0])
        wkHoursList.append(item[0])
        item[1] = float(item[1])
        wkHoursList.append(item[1])

        return True
    except Exception as err:
        return False


##############processLine##############
# checks if a file line has 5 items in it. If it does
# it then uses checkItem to ensure it is the right data type.
# If it is not, an errorList is appended with that line.
#
def processLine(line, numList, lnameList, fnameList, rateList, depList, errList):
    items = line.split()
    if len(items) == 5: #if enough items, execute
        if checkItems(items[0], items[3], items[4]): #if items are correct data type, exe.
            numList.append(int(items[0]))
            lnameList.append(items[1])
            fnameList.append(items[2])
            rateList.append(float(items[3]))
            depList.append(int(items[4]))
        else:
            errList.append(line)
    else:
        errList.append(line)


##############processFileList##############
# Just sends lines to processLine for checking
#
def processFileList(theLine, numList, lnameList, fnameList, rateList, depList, errList):
    for i in range(len(theLine)):
        processLine(theLine[i], numList, lnameList, fnameList, rateList, depList, errList)


##############processHoursListt##############
# Just sends lines to convertHours for conversion
#
def processHoursList(hours, wkHoursList):
    for i in range(len(hours)):
        convertHours(hours[i], wkHoursList)



##############useLists##############
# Asks the user for an ID# to search and runs input val on that entry.
# Sentinel value loop will take input and fetch list with info if
# it exists.
#
def useLists(numList, lnameList, fnameList, rateList, depList, errList):
    for i in range(len(numList)):
        userNum = -1 #sentinel value
        while (userNum != 0):
            userNum = input("Enter employ ID# (0 to stop): ")
            try:
                userNum = int(userNum)
                if(userNum == 0):
                    return #exits program
                i = numList.index(userNum) #i == list of user input employee info
                print('ID: ' + str(numList[i]))
                print('First Name: ' + fnameList[i])
                print('Last Name: ' + lnameList[i])
                print('Pay Rate: $%1.2d' %rateList[i])
                print('Dependents: ' + str(depList[i]))

            except Exception as err:
                print('Not a valid ID or value not found\n')

        #print(str(numList[i]) + '  ' + lnameList[i] + '  ' + fnameList[i] + '  ' +
        #str(rateList[i]) + '  ' + str(depList[i]))

##############main##############
# main function to initialize lists, and file to readlines, and
# will print the error list message if a error was found or not.
#
def main():
    numList = [] # init these lists to empty
    lnameList = []
    fnameList = []
    rateList = []
    depList = []
    errList = []
    wkHoursList = []

    dataFile = open("employeeFile.txt", 'r') #open file
    hrFile = open("weeklyHours.txt", 'r') #open file
    empList = dataFile.readlines() #read file
    wkHours = hrFile.readlines() #read file
    processHoursList(wkHours, wkHoursList)
    processFileList(empList, numList, lnameList, fnameList, rateList, depList, errList) #call

    dataFile.close()#always close
    hrFile.close()#always close

    print(wkHoursList)
    print('There are ' + str(len(errList)) + ' lines with errors') #prints error amount
    if(len(errList) > 0):
        outFile = open("errorLog.txt", 'w')
        for i in range (len(errList)):
            outFile.write(errList[i]) #writes errors to errorLog.txt
        print('Check "errorLog.txt" for error log results.')
        outFile.close()
    useLists(numList, lnameList, fnameList, rateList, depList, errList) #calls useList to get input



#global statement
main()

