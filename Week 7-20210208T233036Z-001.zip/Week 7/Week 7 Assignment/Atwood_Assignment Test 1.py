def processHoursList(hours):
    for i in range(len(hours)):
        convertHours(hours[i])

def convertHours(wkHours):
    item = wkHours.split()
    try:
        int(item[0])
        float(item[1])
        #print(item[0], end=' ')
        #print(item[1])
        return True
    except Exception as err:
        return False



hrFile = open("weeklyHours.txt", 'r') #open file
wkHours = hrFile.readlines() #read file
processHoursList(wkHours)
hrFile.close()#always close