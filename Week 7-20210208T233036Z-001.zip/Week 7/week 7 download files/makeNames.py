# make file names
#
import random
random.seed()


readFile = open("names.txt",'r')
writeFile = open("fnames.txt",'w')
nameList = readFile.readlines()
for i in range(len(nameList)):
    num = random.randint(1,10)
    name = nameList[i]
    if name[-1] == '\n':
        name = name[0:-1]

    if(num == 1):
        writeFile.write('"' + name + '"')
    elif num == 2:
        writeFile.write('(' + name + ')')
    elif num == 3:
        writeFile.write("'" + name + "'")
    elif num == 4:
        writeFile.write("{" + name + "}")
    elif num == 5:
        writeFile.write("[" + name + "]")
    elif num == 6:
        writeFile.write("<" + name + ">")
    else:
        writeFile.write(name)

    writeFile.write('\n')


readFile.close()
writeFile.close()

