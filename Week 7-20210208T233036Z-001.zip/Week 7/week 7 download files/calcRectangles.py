#
# demo of readLines, split, and trys
#
def getArea(l,w):
    return (l*w)

def getPerimeter(l,w):
    return (l+w)*2

def testItem(item):
    try:
        num = float(item)
        return True
    except Exception as err:
        return False


def processItems(line):
    items = line.split()
    if len(items) == 2:
        if not testItem(items[0]) or not testItem(items[1]):
            print(line + " has an invalid item")
        else:
            area = getArea(float(items[0]),float(items[1]))
            perimeter = getPerimeter(float(items[0]),float(items[1]))
            print(line + "   Area: " + str(area) + "   Perimeter: " + str(perimeter))
    else:
        print(line + " does not have two items")



def calcList(theList):
    for i in range(len(theList)):
        processItems (theList[i])

#
# start of main program
#
inFile = open("rectangles.txt",'r')
print("Calculating information on rectangles\n********************\n")
recList = inFile.readlines()
calcList(recList)
inFile.close()