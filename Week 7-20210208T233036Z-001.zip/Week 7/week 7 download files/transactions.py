# transactions.py
#
# this script demos the slice function built into strings
#
# it reads values from a file that have negative values in ( )'s rather
# than a negative sign. It converts these values to a valid negative float value
#


# this functions converts strings that start and stop with ( )'s
# to a string that starts with a -
# designed to convert negative values formatted with ( )'s to -
#
def convert(strItem):
    if strItem[-1] == '\n':
        strItem = strItem[0:-1]

    if strItem[0] == '(' and strItem[-1] == ')':
        #print('-' + strItem[1:-1])
        return '-' + strItem[1:-1]

    else:
        return strItem


# this function adds the value in strValue (string) to a list as a float
# assumes negative values in ( )'s
#
# also uses a try block to be sure of correct values
# invalid items are printed to an error list with line numbers
#
def addValue(strValue, transList, errorList, lineNum):
    newValue = convert(strValue)
    try:
        amount = float(newValue)
        transList.append(amount)
    except Exception as err:
        errorList.append("Line #" + str(lineNum) + ": " + strValue)





def processAmounts(transList):
    posCount = 0
    negCount = 0
    total = 0

    for i in range(len(transList)):
        if transList[i] >= 0:
            posCount +=1
        else:
            negCount += 1

        total += transList[i]

    print("There were " + str(len(transList)) + ' transactions')
    print("The total of these transactions is $%.2f"%total)
    print("There were " + str(posCount) + " positive transactions")
    print("There were " + str(negCount) + " negative transactions")

# displays # of errors and creates errorLog file if any
#
def processErrors(errorList):
    if len(errorList) == 0:
        print("\nThere were no lines that had invalid amounts")
    else:
        errFile = open("errorLog.txt",'w')
        for i in range(len(errorList)):
            errFile.write(errorList[i])

        errFile.close()
        print("\nThere were " + str(len(errorList)) + " lines that had invalid amounts")
        print("Check the file 'errorLog.txt' for the list")


# function to handle list of lines
def handleLines(lines) :
    listGood = []
    listBad = []
    for i in range(len(lines)):
        addValue(lines[i],listGood, listBad, (i+1))

    processAmounts(listGood)
    processErrors(listBad)

# main program
#
def main():
    print("Reading and processing transactions from transactions.txt...")
    inFile = open('transactions.txt')
    rawLines = inFile.readlines()
    handleLines(rawLines)
    inFile.close()


# OK, now lets start things off
main()