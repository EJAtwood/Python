#
# demo of readLines, split, and trys
#
# alternate way to check for invalid numbers
#
def getArea(l,w):
    return (l*w)

def getPerimeter(l,w):
    return (l+w)*2


def processItems(line):
    items = line.split()
    if len(items) == 2:
        try:
            area = getArea(float(items[0]),float(items[1]))
            perimeter = getPerimeter(float(items[0]),float(items[1]))
            print(line + "   Area: " + str(area) + "   Perimeter: " + str(perimeter))
        except Exception as err:
            print(line + " has an invalid item")
    else:
        print(line + " does not have two items")



def calcList(theList):
    for i in range(len(theList)):
        processItems (theList[i])

#
# start of main program
#
inFile = open("rectangles.txt",'r')
print("Calculating information on rectangles\n********************\n")
recList = inFile.readlines()
calcList(recList)
inFile.close()