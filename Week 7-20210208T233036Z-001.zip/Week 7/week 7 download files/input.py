choice = 1
while choice == 1:
    num = float(input("Enter a number: "))
    print("The number you entered is: " + str(num))
    choice = int(input("Enter 1 to do it again, 0 to stop: "))