'''
Name: Ethan Atwood
Date: 7/9/2020
File Name: Atwood_Step 2 Lab 7
Description:
'''

def checkItems(a,x,b):
    try:
        int(a)
        float(x)
        int(b)
        return True
    except Exception as err:
        return False


def processLine(line):
    items = line.split()
    if len(items) == 5:
        if checkItems(items[0], items[3], items[4]):
            return ">>Items are valid and are good to go!<< "
        else:
            return ">>Issue with an item!<< "
    else:
        return ">>>> There are NOT enough items! <<<< "


def processFileList(theLine):
    for i in range(len(theLine)):
        temp = processLine(theLine[i])
        print(temp + str(i+1) + ": " + theLine[i], end='')


def main():
    dataFile = open("employeeFile.txt", 'r')
    empList = dataFile.readlines()
    processFileList(empList)

    dataFile.close()


#global statement
main()