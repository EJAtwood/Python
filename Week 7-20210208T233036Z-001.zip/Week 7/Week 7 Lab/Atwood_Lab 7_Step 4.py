'''
Name: Ethan Atwood
Date: 7/9/2020
File Name: Atwood_Step 3 Lab 7
Description: Reads an employee stat file with employee ID#, first and last name,
hourly rate, and # of dependents. The file is read for valid information and if so,
reports no errors. If errors, an error log is generated. The user can enter an
employee ID# to search that employees information.
'''
##############checkItems##############
# converts table data to ints and floats if possible.
# and returns true if it can. Otherwise the data returns
# false and the data is wrong in the table somewhere
#
def checkItems(a,x,b):
    try:
        int(a)
        float(x)
        int(b)
        return True
    except Exception as err:
        return False

##############processLine##############
# checks if a file line has 5 items in it. If it does
# it then uses checkItem to ensure it is the right data type.
# If it is not, an errorList is appended with that line.
#
def processLine(line, numList, lnameList, fnameList, rateList, depList, errList):
    items = line.split()
    if len(items) == 5:
        if checkItems(items[0], items[3], items[4]):
            numList.append(int(items[0]))
            lnameList.append(items[1])
            fnameList.append(items[2])
            rateList.append(float(items[3]))
            depList.append(int(items[4]))
        else:
            errList.append(line)
    else:
        errList.append(line)

##############processFileList##############
# Just sends lines to processLine for checking
#
def processFileList(theLine, numList, lnameList, fnameList, rateList, depList, errList):
    for i in range(len(theLine)):
        processLine(theLine[i], numList, lnameList, fnameList, rateList, depList, errList)

##############useLists##############
# Asks the user for an ID# to search and runs input val on that entry.
# Sentinel value loop will take input and fetch list with info if
# it exists.
#
def useLists(numList, lnameList, fnameList, rateList, depList, errList):
    for i in range(len(numList)):
        userNum = -1
        while (userNum != 0):
            userNum = input("Enter employ ID# (0 to stop): ")
            try:
                userNum = int(userNum)
                if(userNum == 0):
                    return
                i = numList.index(userNum)
                print('ID: ' + str(numList[i]))
                print('First Name: ' + fnameList[i])
                print('Last Name: ' + lnameList[i])
                print('Pay Rate: $%1.2d' %rateList[i])
                print('Dependents: ' + str(depList[i]))

            except Exception as err:
                print('Not a valid ID or value not found\n')

        #print(str(numList[i]) + '  ' + lnameList[i] + '  ' + fnameList[i] + '  ' +
        #str(rateList[i]) + '  ' + str(depList[i]))

##############main##############
# main function to initialize lists, and file to readlines, and
# will print the error list message if a error was found or not.
#
def main():
    numList = []
    lnameList = []
    fnameList = []
    rateList = []
    depList = []
    errList = []

    dataFile = open("employeeFile.txt", 'r')
    empList = dataFile.readlines()
    processFileList(empList, numList, lnameList, fnameList, rateList, depList, errList)
    dataFile.close()

    print('There are ' + str(len(errList)) + ' lines with errors')
    if(len(errList) > 0):
        outFile = open("errorLog.txt", 'w')
        for i in range (len(errList)):
            outFile.write(errList[i])
        print('Check "errorLog.txt" for error log results.')
        outFile.close()
    useLists(numList, lnameList, fnameList, rateList, depList, errList)

#global statement
main()