'''
Name: Ethan Atwood
Date: 7/9/2020
File Name: Atwood_Step 3 Lab 7
Description:
'''

def checkItems(a,x,b):
    try:
        int(a)
        float(x)
        int(b)
        return True
    except Exception as err:
        return False


def processLine(line, numList, lnameList, fnameList, rateList, depList, errList):
    items = line.split()
    if len(items) == 5:
        if checkItems(items[0], items[3], items[4]):
            numList.append(int(items[0]))
            lnameList.append(items[1])
            fnameList.append(items[2])
            rateList.append(float(items[3]))
            depList.append(int(items[4]))
        else:
            errList.append(line)
    else:
        errList.append(line)


def processFileList(theLine, numList, lnameList, fnameList, rateList, depList, errList):
    for i in range(len(theLine)):
        processLine(theLine[i], numList, lnameList, fnameList, rateList, depList, errList)


def useLists(numList, lnameList, fnameList, rateList, depList, errList):
    for i in range(len(numList)):
        print(str(numList[i]) + '  ' + lnameList[i] + '  ' + fnameList[i] + '  ' +
        str(rateList[i]) + '  ' + str(depList[i]))


def main():
    numList = []
    lnameList = []
    fnameList = []
    rateList = []
    depList = []
    errList = []

    dataFile = open("employeeFile.txt", 'r')
    empList = dataFile.readlines()
    processFileList(empList, numList, lnameList, fnameList, rateList, depList, errList)
    dataFile.close()

    print('There were ' + str(len(errList)) + ' lines in error')
    useLists(numList, lnameList, fnameList, rateList, depList, errList)

#global statement
main()