'''
Name: Ethan Atwood
Date: 7/9/2020
File Name: Atwood_Step 1 Lab 7
Description:
'''

def processFileList(listOfLines):
    for i in range(len(listOfLines)):
        print(str(i+1) + ": " + listOfLines[i], end='')

def main():
    dataFile = open("employeeFile.txt", 'r')
    empList = dataFile.readlines()
    processFileList(empList)

    dataFile.close()


#global statement
main()