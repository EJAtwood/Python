'''
Name: Ethan Atwood
Date: 7/1/2020
File Name: Atwood_Assign 6
Description:
'''

def meters(feet):
    m = feet * 0.3048
    return m

def centimeters(feet):
    c = feet * 30.48
    return c

def kilometers(feet):
    k = feet * 0.0003048
    return k

fileName = input("Enter the filename (with extension) to read from: ") #asks for filename
dataFile = open(fileName,'r') #opens for read
readIn = dataFile.readlines() #reads all lines
print('Done reading...') #tells user it is done reading


fileOut = input('Enter the filename you would like to write to (with extension): ') #asks for output file name
fileOutWrite = open(fileOut, 'w') #opens for write
fileOutWrite.write('%35s' % ('Conversion Table\n'))
fileOutWrite.write('%10s%15s%12s%15s' %("Feet","Centimeters",
"Meters", " Kilometers\n")) #write line amount
fileOutWrite.write(' ===================================================\n')


#converts list to integers
for i in range (0, len(readIn)):
    readIn[i] = float(readIn[i])
    f = readIn[i]
    m = meters(readIn[i])
    c = centimeters(readIn[i])
    k =kilometers(readIn[i])

    #print(round(readIn[i], 2))
    fileOutWrite.write('%10.2f%15.2f%12.2f%15.3f\n'%(f,c,m,k))

dataFile.close()
fileOutWrite.close()