'''
Name: Ethan Atwood
Date: 7/1/2020
File Name: Atwood_Lab 6
Description: Takes in a file name from user. The file must exist already.
When it is opened it reads the lines and tells the user it has done so.
It asks what filename to output to and prints the number of lines, and then
each lines contents labled with a line number. All formated as asked.
'''


fileName = input("Enter the filename (with extension) to read from: ") #asks for filename
dataFile = open(fileName,'r') #opens for read
readIn = dataFile.readlines() #reads all lines
print('Done reading...') #tells user it is done reading

fileOut = input('Enter the filename you would like to write to (with extension): ') #asks for output file name
fileOutWrite = open(fileOut, 'w') #opens for write
fileOutWrite.write('The file contains ' + str(len(readIn)) + ' lines:\n\n') #write line amount
for i in range (len(readIn)): #for loop for line amount
    fileOutWrite.write('\t' + str(i + 1) + '. ' + readIn[i]) #writes line content and line #

print('Check "' + fileOut + '" for output') #tells the user where to look for output

#always make sure to close the files!
dataFile.close()
fileOutWrite.close()
