#fileExample4.py
#
# uses formatted output to create tabular results
# asks user for the filename for input
#
# assumes the file is in the CWD (current working directory)
#
fileName = input("Enter the filename (with extension) to read Fahrenheit temperatures from: ")

dataFile = open(fileName,'r')
resultFile = open("ctemps.txt",'w')
lines = dataFile.readlines() #lines becomes a list. Each item in the list is a full line from the file
# print table headings in output file
resultFile.write('%10s%10s\n=======================\n'%("Farenheit","Celsius"))
for i in range (len(lines)):
        f = float(lines[i])
        c = (f-32)*(5.0/9.0)
        resultFile.write('%10.3f%10.3f\n'%(f,c))

dataFile.close()
resultFile.close()
print("Done. Results are in ctemps.txt")


