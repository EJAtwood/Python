
myFile = open("Text.txt",'r')
lines = myFile.read()
print(lines)
myFile.close()
