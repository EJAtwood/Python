# Scope Demonstration
#
# Scope refers to to where a name, usually a variable's name, has meaning and what it refers to
#

# here is a program that uses a function to convert temeratures from Farhenheit to Celsius
#
#first, the function
def fToC(F):
    C = (F-32)*(5.0/9.0)
    return C

# now the program
degree = float(input("Enter degrees F: "))
while(degree > -999):
    C = fToC(degree)
    print(str(degree) + " degees F is " + str(C) + " degrees C")
    degree = float(input("Enter degrees F (-999 to stop): "))

# so far, all seems normal. Let's modify C in the global scope, and then print it in the local scope

C = 3.14159
print("Converting 212 F: " + str(fToC(212)))
print("Here C is: " + str(C))
#notice that C is not the C used inside the function
input("Hit enter to continue...")
# this does not mean that functions cannot "see" global variables
num = 66.341 #num is global
val = 7.0023 # so is val
amount = 0.0

def goofy(amount):  # formal parameter names are also local
    val = 8.22 # now we have new val, local to goofy
    print("In goofy, amount is : " + str(amount) + " val is: " + str(val) + "  num is: " + str(num))

# OK, now let's call goofy
goofy(100.0)

# and now let's print the variables

print("In global area, amount is : " + str(amount) + " val is: " + str(val) + "  num is: " + str(num))
input("Hit enter to continue...")

# So, val and amount are different variables,
# each with their own memory locations inside goofy and globally
#
# Also notice that num is ONLY in the global area, but is read-only inside goofy
#
num = 34.98
temp = 89.99
goofy(temp)
print("In global area part 2, amount is : " + str(amount) + " val is: " + str(val) + "  num is: " + str(num))

#
# if we try to change num inside of goofy, we get an error unless we specify it to be global
#

def goofy2(amount):  # formal parameter names are also local
    global num
    val = 8.22 # now we have new val, local to goofy
    print("In goofy2, amount is : " + str(amount) + " val is: " + str(val) + "  num is: " + str(num))
    num = num / 2.0

num = 198.22
temp = 30.01
goofy2(temp)
print("In global area part 3 (goofy2), amount is : " + str(amount) + " val is: " + str(val) + "  num is: " + str(num))