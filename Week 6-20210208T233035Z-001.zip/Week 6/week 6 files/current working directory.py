from pathlib import Path
import os
loc = Path.cwd()
print('loc: ' + str(loc))