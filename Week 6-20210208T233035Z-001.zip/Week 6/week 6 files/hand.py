# hand.py
# by Robert Van Cleave
# demonstrates lists, functions random numbers and elif statements
#


import random
random.seed()

def getCard():
    rank = random.randint(1,13)
    suit = random.randint(1,4)

    if rank == 1:
        card = "A"
    elif rank == 11:
        card = "J"
    elif rank == 12:
        card = "Q"
    elif rank == 13:
        card = "K"
    else:
        card = str(rank)

    if suit == 1:
        card = card + '\u2663'
    elif suit == 2:
         card = card + '\u2662'
    elif suit == 3:
        card = card + '\u2661'
    elif suit == 4:
         card = card + '\u2660'

    return card

def printHand(hand):
    print("Your hand: ",end='')
    for i in range (len(hand)):
        print(hand[i] + ' ', end='')
    print()

# begin main program
choice = 1
while choice == 1:
    hand = []
    while choice == 1:
        hand = hand + [getCard()]
        printHand(hand)
        choice = int(input("Get another card? (1 for yes, 0 for no)"))
    choice = int(input("Reset hand? (1 for yes, 0 to quit)"))






