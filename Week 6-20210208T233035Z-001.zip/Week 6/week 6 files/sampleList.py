#
# sampleList.py
#
# this script demostrates lists and for loops
#
def printList(theList):
    for i in range (len(theList)):
        print("Name # " + str(i) + ": " + theList[i])


nameList = ['Sam','Molly','Juan','Chris','Pat','Jane','Bob']

print(len(nameList))

print(nameList[3])

input("Point 1. Hit enter....")


printList(nameList)

input("Point 2. Hit enter....")



nameList[0] = 'Francois'
del nameList[4]
nameList = nameList + ['Enrique',"Henry"]
printList(nameList)

input("Point 3. Hit enter....")

yourName = input("Enter your name: ")
nameList = nameList + [yourName]
printList(nameList)

