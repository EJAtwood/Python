# months.py
#
# demonstrates a simple list
#
# create a list of 12 words, indices 0-11
months = ['January','February','March','April','May','June','July','August','September','October','November','December']

choice = 'y'
while choice == 'y':
    num = int(input("Enter a number from 1 to 12: "))
    print("That month is: " + months[num-1])
    choice = input("Do another? (y or n): ")

print("Good-bye!")
