myFile = open('Text.txt', 'r')
lines = myFile.readlines()
print(lines)

myFile.close()