'''
Name: Ethan Atwood
Date: 6/29/2020
File Name: Atwood_Lab 5
Description: Asks the user to roll some dice and the dice are displayed
and totaled for the user. Three function are used: getFace(), rollDice(),
and main. getFace() is passed the param d to print the die face. rollDice(),
uses two random numbers 1-6 to total and to determine die faced. Main
assigns a value to rollDice(), prints, and loops.

'''
#imported libraries
import random
random.seed()

# set variables to be the unicode charaters for dice faces
one = '\u2680'
two = '\u2681'
three = '\u2682'
four = '\u2683'
five = '\u2684'
six = '\u2685'


####################getFace()####################
# Function when called will pass in an argument (d)
# which will print a dice face value to the screen
#
def getFace(d):
    if(d == 1):
        print(one + ' ', end='')
    elif (d == 2):
         print(two + ' ', end='')
    elif (d == 3):
         print(three + ' ', end='')
    elif (d == 4):
         print(four + ' ', end='')
    elif (d == 5):
         print(five + ' ', end='')
    else:
         print(six + ' ', end='')
    return d


####################rollDice()####################
# Function when called will assign a random 1-6 value
# to d1 or d2. Then it will pass it as an arg. to
# getFace. The sum of the dices is calculated and returned
# as an int(total) to main. No param passed to it.
#
def rollDice():
    d1 = random.randint(1,6) #calcsrand number for d1
    d2 = random.randint(1,6) #calcsrand number for d2
    print("You rolled ",end='')
    total = getFace(d1) + getFace(d2) #calls getFace function twice, passing it d1 and d2 args, sums them also
    return int(total) #return statement to main as integer


####################Main####################
# Main function simply assigns a value to the
# the function rollDice(), displays that value,
# and loops.
#
choice = ""
while choice != 'q':
    input("Hit enter to roll...") # this is a "pause" statement
    diceValue = rollDice() #calls rollDice()
    print('for a total of ' + str(diceValue)) #prints value
    choice = input("Hit enter to roll again, q to quit: ") #asks again for loop

print("So long...")