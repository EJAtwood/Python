# widgetsLab.py

#Write a script that calculates an invoice for widgets. The cost is as follows:
#1-9 widgets: $3.50 each
#10-99 widgets: $3.00 each
#100 or more: $2.75 each
#
# However, if a customer has a loyalty card they are charged $2.75 each regardless of the amount.

#calculate tax at 6%, and calculate the total due

# variables:
#   input: amount int
#           card string
#
#   calculated: cost_per_widget, subtotal, tax, total float

#Output: Amount, Price per each, Sub-total, Tax, total

#Key programing structures: if-elif-elif-else block
#
#test data
#
#   amount  card    price   subtotal    tax     total
#   9       n       3.50    31.50       1.89    33.39
#   9       y       2.75    24.75       1.48    26.23
#   10      n       3.00    30.00       1.80    31.80
#   99      n       3.00    297.00      17.82   314.82
#   100     n       2.75    275.00      16.50   291.50
#
# below is a function definition. It is not executed until called
# amount is the formal parameter
def currency (amount):
    dollars = int(amount)
    cents = int ((amount - dollars) * 100 + 0.49)
    results =  '$' + str(dollars) + '.' + str(cents)
    return results

card = input('Do you have a loyalty card? (y or n): ')
amount = int(input('How many widgets do you want?: '))
if card == 'y':
    price_per_each = 2.75
elif amount <= 9:
    price_per_each = 3.50
elif amount <= 99:
    price_per_each = 3.00
else:
    price_per_each = 2.75

subtotal = amount * price_per_each
tax = subtotal * 0.06
total = subtotal + tax
print("Amount ordered: %1d"%amount)
print("Price per each: " + currency(price_per_each))
print("Subtotal: " + currency(subtotal))
print("Tax: " + currency(tax))
print("Total due: " + currency(total))