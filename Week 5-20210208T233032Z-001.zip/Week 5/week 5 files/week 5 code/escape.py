# escape sequences
#
# in a quoted string \ is an escape character
#
#
# /n   end of line
# /t   tab
# //   backslash
# /" or /'  the quote charater
# /uHHHH   unicode
#
print("1. This is one line, and there are no escape characters.")
print("2. This is on one line \nAnd this is on another. \\n was used")
print("3.\ttab1\ttab2\ttab3")
print("4. Using a \" inside a string")
print('5. Another way, just use the other quotes: "  ')
print(r'6. Use an r before the string to print "raw" \n \t \\ \" ')