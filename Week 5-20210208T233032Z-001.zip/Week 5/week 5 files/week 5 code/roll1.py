# roll1.py
#
# simulates rolling a pair of dice
#
import random
random.seed()
# the above two lines must be there to work right

choice = ""
while choice != 'q':
    d1 = random.randint(1,6)
    d2 = random.randint(1,6)
    roll = d1 + d2
    print("You rolled : " + str(d1) + " and " + str(d2) + " for a total of: " + str(roll))
    choice = input("Hit enter to roll again, q to quit: ")

print("So long...")