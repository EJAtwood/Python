# currencyFormat
#
# this program tests a function currency that takes a parameter of float, and prints a string
# with the float value rounded to two decimals and with a $ in front.
#
# below is a function definition. It is not executed until called
# amount is the formal parameter
def currency (amount):
    dollars = int(amount)
    cents = int ((amount - dollars) * 100 + 0.49)
    results =  '$' + str(dollars) + '.' + str(cents)
    return results

# below is the first line of code executed when the program runs
value = float(input('Enter a float value: '))
while value != 0.0:
    money = currency(value) #this line includes a call to currency
                            #the actual parameter sent is value
                            #the return value is stored in a variable called money
    print('The value you entered in currency would be: ' + money)
    value = float(input('Enter a float value (0.0 to stop): '))