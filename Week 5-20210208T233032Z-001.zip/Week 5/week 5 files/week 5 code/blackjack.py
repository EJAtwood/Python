# blackjack.py
#
# play a simplified version of balckjack. Aces are always 11
#
# cards have two data points: their face and their suit
# there a four suits, and 13 faces: Ace through King
# a single card may be represented by a single number 0 through 51
#
# to determine the face and suit of a number:
#     face = number % 13 (produces a value 0 to 12)
#     suit = number // 13 (produces a value 0 - 3)
#
#     to make using the face easier, add 1 to the results,
#     getting a value 1-13.
#
import random
random.seed()

spade = '\u2660'
heart = '\u2661'
diamond = '\u2662'
club = '\u2663'

#this function prints a card and returns it's face value
# Aces are 1, face cards 10, all others are what there are
#
def printFace(face):
    #print the face and determine it's value
    if face == 1:
        print('A', end="")
        value = 11
    elif face == 11:
        print('J', end="")
        value = 10
    elif face == 12:
        print('Q', end="")
        value = 10
    elif face == 13:
        print('K', end="")
        value = 10
    else:
        print(str(face), end="")
        value = face
    #return it's value
    return value

def printSuit(suit):
    if suit == 0:
        print(club, end="")
    elif suit == 1:
        print(diamond, end="")
    elif suit == 2:
        print(heart, end="")
    else:
        print(spade, end="")
    # nothing to return, void function

def getCard():
    num = random.randint(0,51) # pick a card
    f = (num % 13) + 1
    s = num // 13
    amount = printFace(f)
    printSuit(s)
    return amount

# here is where the code begins execution
choice = ""
while choice != 'q':
    print("You have: ", end="")
    total = getCard()
    print(" and ",end="")
    total += getCard()
    print("\nyour total is: " + str(total))

    while choice != 'n' and total < 21:
        choice = input("Hit? y or n: ")
        while choice != 'n' and choice != 'y':
            choice = input("Error! enter y or n: ")

        if choice == 'y':
            print('Next card is: ', end="")
            total += getCard()
            print("Your total is now: " + str(total))

    print('Your final total is: ' + str(total))
    if total == 21:
        print("BlackJack!")
    elif total > 21:
        print("Bust!")

    choice = input("Hit enter to play again, q to quit: ")