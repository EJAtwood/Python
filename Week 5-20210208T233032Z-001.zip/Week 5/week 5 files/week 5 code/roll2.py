# roll1.py
#
# simulates rolling a pair of dice
#
# adds unicode characters
#
import random
random.seed()
# the above two lines must be there to work right

# set variables to be the unicode charaters for dice
one = '\u2680'
two = '\u2681'
three = '\u2682'
four = '\u2683'
five = '\u2684'
six = '\u2685'

def Roll(d):
    if(d == 1):
        print(one + ' ', end='')
    elif (d == 2):
         print(two + ' ', end='')
    elif (d == 3):
         print(three + ' ', end='')
    elif (d == 4):
         print(four + ' ', end='')
    elif (d == 5):
         print(five + ' ', end='')
    else:
         print(six + ' ', end='')
    return d

choice = ""
while choice != 'q':
    input("Hit enter to roll...") # this is a "pause" statement
    d1 = random.randint(1,6)
    d2 = random.randint(1,6)
    roll = Roll(d1) + Roll(d2)
    print("You rolled : ",end='')
    print(" for a total of " + str(roll))
    choice = input("Hit enter to roll again, q to quit: ")

print("So long...")