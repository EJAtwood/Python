# GrossPay2.py
#
# Rob Van Cleave
#
# Requirements:
# Given hours and rate:
#    Calculate gross pay as follows:
#        Pay is hours * rate, except all hours over 40
#           are paid at 1.5 times the rate
#
# variables
#   input: hours, rate
#   calculated: OThours, gross
#
# output: gross and OThours
#


#
# Key calculations and programming structures
#
# calculate gross:
#   if hours > 40 then
#       OThours = hours - 40
#       gross = rate * 40.00 + (OThours * rate * 1.5)
#   else
#       OThours = 0
#       gross = hours * rate
#
# Test data: (Note how the 'border' is tested)
#
# hours 	rate	    OThours	gross
# 40.0  	25.00	    0	        $1,000.00
# 40.25 	25.00	    0.25	$1,009.38
#
# Note: this version uses %.2f for rounding and decimals
#
#
#
# below is a function definition. It is not executed until called
# amount is the formal parameter
def currency (amount):
    dollars = int(amount)
    cents = int ((amount - dollars) * 100 + 0.49)
    results =  '$' + str(dollars) + '.' + str(cents)
    return results

print("Enter the hourly pay rate: $",end='')
rate = float(input())
print("Enter the # of hours worked: ",end='')
hours = float(input())

if hours > 40.00:
    OThours = hours - 40.00
    gross = rate * 40.00 + (OThours * rate * 1.5)
else:
    OThours = 0.0
    gross = hours * rate

print("Overtime hours: %.2f" % OThours)
print("Gross pay: " + currency(gross))