'''
Name: Ethan Atwood
Date: 6/29/2020
File Name: Atwood_Assignment 5 (Craps)
Description: Asks the user to roll some dice and the dice are displayed
and totaled for the user. Depending on the Come Out Roll, the game will change.
When a COR 7 or 11 encounterd, a win! a 2,3, or 12, a loss. Any other value will
enter the Point round. Within that round, the user can hit the point to win, or
a 7 to lose.

I added some additional items in my code from your lecture videos as practice
(more unicdoe symbols, end lines, \", and tabs).

'''
#imported libraries
import random
random.seed()

# set variables to be the unicode charaters for dice faces
one = '\u2680'
two = '\u2681'
three = '\u2682'
four = '\u2683'
five = '\u2684'
six = '\u2685'
smile = '\u263A' #extra fun

#####################pointRoubnd()####################
# Function takes a int as an param and sets that to the point value.
# the user rolls again to hit the point value. If successful, a win.
# A 7 in this function is a loss, and any other value causes a re-roll
#
def pointRound(point):
    results = int(0) #results to 0 as instructions for seed
    print('You are in the point round. Your point value is: ' + str(point))#note to user

    while (results == 0):#when 0 dice roll loops, if not exit
        input("Hit enter to roll the dice...") # this is a "pause" statement
        diceValue = rollDice() #calls rollDice()
        print('for a total of ' + str(diceValue)) #prints value

        if (diceValue == 7): #loss
            print('Do Not Pass, Point round and player turn are over\n')
            results = 2

        elif(diceValue == point): #winner winner
            print('Pass ' + str(smile)+ ', Point round and player turn are over')
            results = 1

        elif(diceValue != 7 or diceValue != point):# if not point or 7, loop again!
            print('Point round - roll again...')
            continue



####################getFace()####################
# Function when called will take a param (d)
# which will print a dice face value to the screen
# for the user to review
#
def getFace(d):
    if(d == 1):
        print(one + ' ', end='')
    elif (d == 2):
         print(two + ' ', end='')
    elif (d == 3):
         print(three + ' ', end='')
    elif (d == 4):
         print(four + ' ', end='')
    elif (d == 5):
         print(five + ' ', end='')
    else:
         print(six + ' ', end='')
    return d


####################rollDice()####################
# Function when called will assign a random 1-6 value
# to d1 or d2. Then it will pass it as an arg to
# getFace. The sum of the dices is calculated and returned
# as an int(total) to main. No param passed to it.
#
def rollDice():
    d1 = random.randint(1,6) #calcsrand number for d1
    d2 = random.randint(1,6) #calcsrand number for d2
    print("You rolled ",end='')
    total = getFace(d1) + getFace(d2) #calls getFace function twice, passing it d1 and d2 args, sums them also
    return int(total) #return statement to main as integer

####################main()####################
#
#fun intro
print('\t' + str(six) + str(five) +' Welcome to the Craps table '+ str(four) + str(three) +'\n')

choice = ""
while choice != 'q':
    input("Shoot the dice for the Come Out Roll (hit enter)...") # this is a "pause" statement
    diceValue = rollDice() #calls rollDice() and sets to value
    print('for a total of ' + str(diceValue)) #prints value

    if (diceValue == 7 or diceValue == 11): #if COR 7 or 11, winner winner
        print('You Pass ' + str(smile) + ', turn is over!')
    elif(diceValue == 2 or diceValue == 3 or diceValue == 12): #loser
        print('You Do Not pass, turn is over!\n')
    elif(diceValue == 4, 5, 6, 8, 9, 10): #enter pointRound() fn
        pointRound(diceValue)

    choice = input("Hit enter to roll again, q to quit: \n") #asks again to play the game!

print("\"What is life if not a gable\"...so long")
