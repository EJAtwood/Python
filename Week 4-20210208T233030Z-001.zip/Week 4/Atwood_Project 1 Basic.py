'''
Name: Ethan Atwood
File Name: Atwood_Project 1 Basic
Description: Takes the number of tickets an individual wants to order for 3 different
sections and calculates the amount due. Mailing costs are also added depending on user
needs. Multiple orders can be placed and a total Summary of order data is produced at
the end of the order.
Variables:
    input:
        aTickets, bTickets, cTickets, aPrice, bPrice, cPrice, mailOut, mailPrice, start

    output:
        aTickets, bTickets, cTickets, aPrice, bPrice, cPrice, mailOut, mailPrice, indiPrice, indiTotal,
        aTicketAmount, bTicketAmount, cTicketAmount, runningTicket, mailAmount, orderCount
Key Calculations:
    aPrice = aTickets * 75 #calculate section A prices
    bPrice = bTickets * 50 #calcuate sectoin B prices
    cPrice = cTickets * 35 #calcuate sectoin C prices
    indiPrice = aPrice + bPrice + cPrice #calcualtes the ticket prices for one single order
    indiTotal = indiPrice + mailPrice #calculates the total ticket and mailing price for a single order
    aTicketAmount = aTicketAmount + aTickets #running counter for section A tickets
    bTicketAmount = bTicketAmount + bTickets #running counter for section B tickets
    cTicketAmount = cTicketAmount + cTickets #running counter for section C tickets
    runningTicket = aRunningPrice + bRunningPrice + cRunningPrice #running counter for all ticket orders
    mailAmount = mailAmount + mailPrice #running counter for mail price
    total = runningTicket + mailAmount #total running price for, only used for debug
    runningTotal = runningTotal + total #counter for runningtotal for all prices for debug
Algorithms:
    A. Initialize all needed counters
    B. While loop starts first iteration of loop (first order),carries out ticket ordering
       function, and asks users to enter sentinel value or to continue the loop for another
       order
    C. Print statements print differently whether or not sentinel value encountered or not
test data:
    A. Matches test output from Project 1 basic.pdf
    B. 3, 0, 0, y: sec A $225.0, sec B $0.00, sec C $0.00, Total $225.00, mail cost $5.50, total due $230.50, y
    C. 2, 4, 1, n: Sec A $150.00, sec B $200.00. sec C$35.00, Total $385.00, mail cost $0.00, total due $385.00, n
    D. Sumamry Data: total orders 2, sec A tick 5, sec b tick 4, sec c tick 1, tick sales $610.00, total mail $5.50
    All sample data given in lines B and C matches expected calcualtions in line D
'''
################Counters###################
# Running counters ticket prices for more than one order including
# seciont a-c ticket amounts, mail prices, order count, and running totals
#
aRunningPrice = 0 #counter for section A running price
bRunningPrice = 0 #counter for section B running price
cRunningPrice = 0 #counter for section C running price
aTicketAmount = 0 #counter for section A tickets sold
bTicketAmount = 0 #counter for section B tickets sold
cTicketAmount = 0 #counter for section C tickets sold
mailAmount = 0 #initializes mailOut to no mail charges, dont need this but tried it out
runningTicket = 0 #counter for all section ticket prices
runningTotal = 0 #debugging statement counter
orderCount = 0 #initilzed to 0 for counter start
start = 'y' # will start loop since not sentinel value of 'n' seed read as 'y'

################While loop###################
# While loop initiates and runs an order and can be looped again
# if the user wants another order. Sentinel value start used to
# determine if loop starts again.
#
while(start != 'n'): #sentinel Value = 'n' meaning if 'n' encountered, loops ends with summary data
    orderCount = orderCount + 1 #running order count within loop

    aTickets = int(input('How many tickets would you like to buy in section A?: ')) #input aTickets
    bTickets = int(input('How many tickets would you like to buy in section B?: ')) #input bTickets
    cTickets = int(input('How many tickets would you like to buy in section C?: ')) #input cTickets

    aPrice = aTickets * 75 #calculate section A prices
    bPrice = bTickets * 50 #calcuate sectoin B prices
    cPrice = cTickets * 35 #calcuate sectoin C prices

    mailOut = input('Send through U.S. Mail (y or n): ') #if else for sending through mail or not
    if(mailOut == 'y'): #if 'y' add $5.50 in mailing charges
        mailPrice = float(5.50)
    else: #if not 'y', do not add 5.50 in mailing chages to the order
        mailPrice = float(0.00)

    aRunningPrice = aRunningPrice + aPrice #calculates the section A orders for summary data
    bRunningPrice = bRunningPrice + bPrice #calculates the section B orders for summary data
    cRunningPrice = cRunningPrice + cPrice #calculates the section C orders for summary data

    indiPrice = aPrice + bPrice + cPrice #calcualtes the ticket prices for one single order
    indiTotal = indiPrice + mailPrice #calculates the total ticket and mailing price for a single order
    aTicketAmount = aTicketAmount + aTickets #running counter for section A tickets
    bTicketAmount = bTicketAmount + bTickets #running counter for section B tickets
    cTicketAmount = cTicketAmount + cTickets #running counter for section C tickets
    runningTicket = aRunningPrice + bRunningPrice + cRunningPrice #running counter for all ticket orders
    mailAmount = mailAmount + mailPrice #running counter for mail price
    total = runningTicket + mailAmount #total running price for, only used for debug
    runningTotal = runningTotal + total #counter for runningtotal for all prices for debug


    print('Total for Tickets in Section A: $%1.2f' %aPrice) #Sec A price or this order
    print('Total for Tickets in Section B: $%1.2f' %bPrice) #Sec B price or this order
    print('Total for Tickets in Section C: $%1.2f' %cPrice) #Sec C price or this order
    print('Total Ticket sales: $%1.2f' %indiPrice) #individual order total ticket prices
    print('Total mailing costs: $%1.2f' %mailPrice) #mail price for this order
    print('Total Due: $%1.2f' %indiTotal) #individual order total Mail + tickets

    start = input('Would you like to make another order (y or n): ') #could triger sentinel value to end loop

print('') #blank line to separate data a little bit more
print('Summary Data:')
print('Total Orders: ' + str(orderCount)) #prints counter # for total orders ordered
print('Total Section A tickets ordered: ' + str(aTicketAmount)) #total running counter for sec A tickets
print('Total Section B tickets ordered: ' + str(bTicketAmount)) #total running counter for sec B tickets
print('Total Section C tickets ordered: ' + str(cTicketAmount)) #total running counter for sec C tickets
print('Total Ticket sales: $%1.2f' %runningTicket) #prints counter for running ticket sales
print('Total mailing costs: $%1.2f' %mailAmount) #prints counter for all mail charges

################Debugging statements#################
# Just a few debug statements I used to ensure proper math
# calculations
#
#print('Total Due (including mailing): $%1.2f' %runningTotal)
#print('Total for Tickets in Section A: $%1.2f' %aRunningPrice)
#print('Total for Tickets in Section B: $%1.2f' %bRunningPrice)
#print('Total fo Tickets in Section C: $%1.2f' %cRunningPrice)

