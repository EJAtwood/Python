'''
Name: Ethan Atwood
Date: 6/24/2020
File Name: Atwood_Project 1 Intermediate
Description: Takes the number of tickets an individual wants to order for 3 different
sections and calculates the amount due. Mailing costs are also added depending on user
needs. Multiple orders can be placed and a total Summary of order data is produced at
the end of the order. Sponsorship table calculated based on ticket order amount and
subsequent needed items are calculated per table.
Variables:
    input:
        aTickets, bTickets, cTickets, mailOut, start

    output:
        aTickets, bTickets, cTickets, aPrice, bPrice, cPrice, mailOut, mailPrice, indiPrice, indiTotal,
        aTicketAmount, bTicketAmount, cTicketAmount, runningTicket, mailAmount, orderCount, wine, certificates,
        dessert, aTables, bTables, cTables
Key Calculations:
    aPrice = aTickets * 75 #calculate section A prices
    bPrice = bTickets * 50 #calcuate sectoin B prices
    cPrice = cTickets * 35 #calcuate sectoin C prices
    indiPrice = aPrice + bPrice + cPrice #calcualtes the ticket prices for one single order
    indiTotal = indiPrice + mailPrice #calculates the total ticket and mailing price for a single order
    aTicketAmount = aTicketAmount + aTickets #running counter for section A tickets
    bTicketAmount = bTicketAmount + bTickets #running counter for section B tickets
    cTicketAmount = cTicketAmount + cTickets #running counter for section C tickets
    runningTicket = aRunningPrice + bRunningPrice + cRunningPrice #running counter for all ticket orders
    mailAmount = mailAmount + mailPrice #running counter for mail price
    total = runningTicket + mailAmount #total running price for, only used for debug
    runningTotal = runningTotal + total #counter for runningtotal for all prices for debug
    wine = (aRunningTable * 2) #calc needed wine per table orders
    dessert = (aRunningTable + bRunningTable) * 6 #calc for running dessert amount
    certificates = (aRunningTable + bRunningTable + cRunningTable) #calc for running certificates
Algorithms:
    A. Initialize all needed counters
    B. While loop starts first iteration of loop (first order),carries out ticket ordering
       function, and asks users to enter sentinel value or to continue the loop for another
       order
    C. If statements used for sponsorship of tables based on integer division of ticket orders
    D. Print statements print differently whether or not sentinel value encountered or not
    E. After loop, conters used to calculated needed items for event
test data:
    A. Matches test output from Project 1 Intermediate.pdf
    B. 4, 12, 16, y: sec A $300.00 sec B $600.00, 2 sponsorship tickets for section B, sec C $560, 2 sponsorship tickets for section B,
    Total $1460, mail cost $5.50, total due $1465.50, y
    C. 13, 4, 1, n: Sec A $975.00, 2 sponsorship tickets for section A sec B $200.00. sec C$35.00, Total $35.00, mail cost $0.00, total
    due $1210.00, n
    D. Sumamry Data: total orders 2, sec A tick 17, sec b tick 16, sec c tick 17, tick sales $2670.00, total mail $5.50 4 bottles of wine,
    24 desserts, 6 certificates
    All sample data given in lines B and C matches expected calcualtions in line D
'''
################Counters###################
# Running counters ticket prices for more than one order including
# seciont a-c ticket amounts, mail prices, order count, and running totals
#
aRunningPrice = 0 #counter for section A running price
bRunningPrice = 0 #counter for section B running price
cRunningPrice = 0 #counter for section C running price
aTicketAmount = 0 #counter for section A tickets sold
bTicketAmount = 0 #counter for section B tickets sold
cTicketAmount = 0 #counter for section C tickets sold
aRunningTable = 0 #counter for section A tables sponsorship sold
bRunningTable = 0 #counter for section B tables sponsorship sold
cRunningTable = 0 #counter for section C tables sponsorship sold
mailAmount = 0 #initializes mailOut to no mail charges, dont need this but tried it out
runningTicket = 0 #counter for all section ticket prices
runningTotal = 0 #debugging statement counter
orderCount = 0 #initilzed to 0 for counter start
start = 'y' # will start loop since not sentinel value of 'n' seed read as 'y'

################While loop###################
# While loop initiates and runs an order and can be looped again
# if the user wants another order. Value start used to
# determine if loop starts again.
#
while(start != 'n'): #sentinel Value = 'n' meaning if 'n' encountered, loops ends with summary data
    orderCount = orderCount + 1 #running order count within loop
    #print('')
    aTickets = int(input('How many tickets would you like to buy in section A?: ')) #input aTickets
    bTickets = int(input('How many tickets would you like to buy in section B?: ')) #input bTickets
    cTickets = int(input('How many tickets would you like to buy in section C?: ')) #input cTickets

    aPrice = aTickets * 75 #calculate section A prices
    bPrice = bTickets * 50 #calcuate sectoin B prices
    cPrice = cTickets * 35 #calcuate sectoin C prices

    mailOut = input('Send through U.S. Mail (y or n): ') #if else for sending through mail or not
    if(mailOut == 'y'): #if 'y' add $5.50 in mailing charges
        mailPrice = float(5.50)
    else: #if not 'y', do not add 5.50 in mailing chages to the order
        mailPrice = float(0.00)

    aRunningPrice = aRunningPrice + aPrice #calculates the section A orders for summary data
    bRunningPrice = bRunningPrice + bPrice #calculates the section B orders for summary data
    cRunningPrice = cRunningPrice + cPrice #calculates the section C orders for summary data

    indiPrice = aPrice + bPrice + cPrice #calcualtes the ticket prices for one single order
    indiTotal = indiPrice + mailPrice #calculates the total ticket and mailing price for a single order
    aTicketAmount = aTicketAmount + aTickets #running counter for section A tickets
    bTicketAmount = bTicketAmount + bTickets #running counter for section B tickets
    cTicketAmount = cTicketAmount + cTickets #running counter for section C tickets
    runningTicket = aRunningPrice + bRunningPrice + cRunningPrice #running counter for all ticket orders
    mailAmount = mailAmount + mailPrice #running counter for mail price
    total = runningTicket + mailAmount #total running price for, only used for debug
    runningTotal = runningTotal + total #counter for runningtotal for all prices for debug

    #divide by 6 and that integer is 6
    # number > 0 they are sponsors of that many tables
    aTables = int(aTickets / 6)
    bTables = int(bTickets / 6)
    cTables = int(cTickets / 6)


    aRunningTable = aRunningTable + aTables #A running table count
    bRunningTable = bRunningTable + bTables #B running table count
    cRunningTable = cRunningTable + cTables #C running table count

    print('') #blank line to separate data a little bit more
    print('Ticket Invoice:')
    print('Section A tickets: ' + str(aTickets) + ' for a price of  $%1.2f' %aPrice) #Sec A price or this order
    if(aTables != 0): #if statement will print sponsoship amount if integer division != to 0
        print('This gives you ' + str(aTables) + ' Section A table sponsorship')
    print('Section B tickets: ' + str(bTickets) + ' for a price of  $%1.2f' %bPrice) #Sec B price or this order
    if(bTables != 0): #if statement will print sponsohip amount if integer division != to 0
        print('This gives you ' + str(bTables) + ' Section B table sponsorship')
    print('Section C tickets: ' + str(cTickets) + ' for a price of  $%1.2f' %cPrice) #Sec C price or this order
    if(cTables != 0): #if statement will print sponsorship amount if integer division != to 0
        print('This gives you ' + str(cTables) + ' Section C table sponsorship')
    print('Total Ticket sales: $%1.2f' %indiPrice) #individual order total ticket prices
    print('Total mailing costs: $%1.2f' %mailPrice) #mail price for this order
    print('Total Due: $%1.2f' %indiTotal) #individual order total Mail + tickets

    start = input('Would you like to make another order (y or n): ') #could triger sentinel value to end loop

wine = (aRunningTable * 2) #cals wine based on the total of all order sponsorship tables needed
dessert = (aRunningTable + bRunningTable) * 6 #calcs deserts needed based on running total table sponsorships
certificates = (aRunningTable + bRunningTable + cRunningTable) #calcs certs for all running ponsorhip tables

print('') #blank line to separate data a little bit more
print('Summary Data:')
print('Total Orders: ' + str(orderCount)) #prints counter # for total orders ordered
print('Total Section A tickets ordered: ' + str(aTicketAmount)) #total running counter for sec A tickets
print('Total Section B tickets ordered: ' + str(bTicketAmount)) #total running counter for sec B tickets
print('Total Section C tickets ordered: ' + str(cTicketAmount))
print('Total Ticket sales: $%1.2f' %runningTicket) #prints counter for running ticket sales
print('Total mailing costs: $%1.2f' %mailAmount) #prints counter for all mail charges
print('')
print('The following will be needed: ') #prints needed items for event
print(str(wine) + ' bottles of wine') #prints amount of wine needed
print(str(dessert) + ' desserts') #prints desserts needed
print(str(certificates) + ' certificates') #prints certificates needed
