'''
Name: Ethan Atwood
File Name: Atwood_Lab 3
Description: Calculates an invoice for widget order determined by customer
and whether they have a loyalty card or not. The calcualtions change depending
on loyalty card owner or not. Amount ordered, price per item, subtotal, tax, and
total are all calculated and displayed
    input:
        widgetsIn
        card
    output:
        amountOrdered #same as widgetsIn
        eachPrice
        subTotal
        tax
        totalDue
Key Calculations:
    total = float(widgetsIn  * price of Widget)
    tax = total * taxes #calculates taxes due
    totalDue = total + tax
Algorithms:
    <= and >= statments correlating amout of widgets to volume price
    of widget
test data:
    all boundaries: 0, 1, 9, 10, 99, 100, 150 (no input validation though)
    in for WidgetsIn
    test 'y' and 'n' entries for all the boundaries
'''
taxes = 0.06 #constant, I didnt need to do this, just wanted to try it out
loyaltyPrice = 2.75 #constant

###################User Input###################
# Prompt user for amount of widgets to order and ask
# if loyalty member or not
#
widgetsIn = int(input('How many widgets would you like to buy?: '))
card = str(input('Do you have a loyalty card y or n?: '))

###################Logic###################
# If the customer is a loyalty memeber, they get the
# discount of 2.75 regardles of order amount. If not,
# they pay depending on amount ordered.
#
if(card == str('y')): #execute if member
    total = float(widgetsIn  * loyaltyPrice)
    print('Price per Widget: $2.75')
    print('Subtotal with the loyalty card is: $%1.2f' %total)

elif(widgetsIn <= 9):
#elif(widgetsIn >= 1 and widgetsIn <= 9): #test bool operator statement between 10 and 99
    total = float(widgetsIn * 3.50)
    print('Widgets ordered: ' + str(widgetsIn))
    print('Price per Widget: $3.50')
    print('Subtotal: $%1.2f' %total)

elif(widgetsIn <= 99):
#elif((widgetsIn >= 10) and (widgetsIn <= 99)): #test bool operator statement between 10 and 99
    total = float(widgetsIn * 3.00)
    print('Widgets ordered: ' + str(widgetsIn))
    print('Price per Widget: $3.00')
    print('Subtotal $%1.2f' %total)

elif(widgetsIn >= 100):
#elif(widgetsIn >= 100): #test bool operator statement greater= 100
    total = float(widgetsIn  * loyaltyPrice)
    print('Widgets ordered: ' + str(widgetsIn))
    print('Price per Widget: $2.75')
    print('Subtotal $%1.2f' %total)

else:
    print('not a valid entry') #debugging statement for proper logic execution
#exit logic

###################Calculations###################
# takes stores values from above and calcualtes taxes
# and total amount due
#
tax = total * taxes #calculates taxes due
print('Tax: $%1.2f' %tax)

totalDue = total + tax #calculates total amount due
print('Total: $%1.2f' %totalDue)

