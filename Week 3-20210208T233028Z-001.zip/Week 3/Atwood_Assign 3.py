'''
Name: Ethan Atwood
File Name: Atwood_Assign 3
Description: The user can determine how many widgets and order amounts they want. For each order,
a running customer count, widget count, average price per widget, running subtotal, tax, and final
total are all kept and output for the user. There is input validation for
loyalty card input (of which could be easily applied to other user input as well).
Variables:
    input:
        widgetsIn
        card
        start
    output:
        amountOrdered
        eachPrice
        subTotal
        tax
        totalDue
        loyaltyMember
        customer
        averageWidgets
        finalSub
        finalTax
        finalTotal
        totalWidgets
Key Calculations: #I only included the non-obvious counter calculations as others are in lab 3
    loyaltyMember = loyaltyMember + 1
    finalSub = round(finalSub + total, 2) #rounded  calc
    finalTax = round(finalTax + tax, 2) #rounded calc
    finalTotal = round(finalSub + finalTax, 2) #rounded calc
    totalWidgets = totalWidgets + widgetsIn
    averageWidgets = finalSub / totalWidgets
    customer = customer + 1 #counts total customers for all orders
Algorithms:
    Loop statement for varying orders as defined by the user.
    Within the loop, if then statements same as lab 3 except for
    the addition of a counters for maintaining different order
    running totals
test data:
    There are millions of combinations but below is a sample:
    Order 1:    2 widgets 'g'n n card
    Order 2:    15 widgets n card
    Order 3:    105 widgets n card
    Order 4:    56 widgets y
    4 total customers, 1 loyalty member, 178 widgets, av/widget 2.78, final subtotal 494.75
    final tax 29.69, final due 524.44
    Tests loops with all four if-else cases and input validation for loyalty card

'''
taxes = 0.06 #constant, I didnt need to do this, just wanted to try it out
loyaltyPrice = 2.75 #constant

###################Initiliaze counters###################
# Initiliaze a variety or oders for use in the while loop.
# count var will begin or exit the loop depending on user input
#
start = str('y') #sentinel value
loyaltyMember = 0 #running total of loyalty members
customer = 0 #running total of total members
averageWidgets = 0 #running widget average price
finalSub = 0 #running subtotal for all orders
finalTax = 0 #running total of tax amount
finalTotal = 0 #running total sub + tax
totalWidgets = 0 #running total of widgets ordered

###################The Loop###################
# Starts the loop which start a widget order
#
while (start == 'y'): #when user input = y (for yes) is true, complete another order

###################User Input###################
# Prompt user for amount of widgets to order and ask
# if loyalty member or not
#
    widgetsIn = int(input('How many widgets would you like to buy?: '))
    card = str(input('Do you have a loyalty card y or n?: '))

    while True: #input validation loop for loyalty Card
        if(card != 'y' and card != 'n'): #if card is no proper input, re-ask user
            print('Please enter y or n')
            card = str(input('Do you have a loyalty card y or n?: '))
        else: #if input is y or n, the input can be processed via rest of program
            break

###################Logic###################
# while loop for widget orders. If member then special
# discount, other specific prices. Within loops, counters
# increment and keep a running total of how many loyalty members,
# normal customers, the running subtotal, taxes, and final total
#
    if(card == str('y')): #Data validation for loyalty member
        total = float(widgetsIn  * loyaltyPrice)
        print('Price per Widget: $2.75')
        print('Subtotal with the loyalty card is: $%1.2f' %total)
        loyaltyMember = loyaltyMember + 1 #counts loyaltyMembers

    elif(widgetsIn <= 9):
        total = float(widgetsIn * 3.50)
        print('Widgets ordered: ' + str(widgetsIn))
        print('Price per Widget: $3.50')
        print('Subtotal: $%1.2f' %total)

    elif(widgetsIn <= 99):
        total = float(widgetsIn * 3.00)
        print('Widgets ordered: ' + str(widgetsIn))
        print('Price per Widget: $3.00')
        print('Subtotal $%1.2f' %total)

    elif(widgetsIn >= 100):
        total = float(widgetsIn  * loyaltyPrice)
        print('Widgets ordered: ' + str(widgetsIn))
        print('Price per Widget: $2.75')
        print('Subtotal $%1.2f' %total)

    else:
        print('not a valid entry') #debugging statement for proper logic execution

    tax = total * taxes #calculates taxes due for individual orders / order
    print('Tax: $%1.2f' %tax)

    totalDue = total + tax #calculates total amount due / order
    print('Total: $%1.2f' %totalDue)

    print('') #prints blank line for formatting

    #counters and rounding for appropriate summary data
    finalSub = round(finalSub + total, 2) #calculates running subtotal before taxs
    finalTax = round(finalTax + tax, 2) #counts all tax for all orders
    finalTotal = round(finalSub + finalTax, 2) #calculates total (tax + subtotal)
    totalWidgets = totalWidgets + widgetsIn # counts all widgets ordered
    averageWidgets = finalSub / totalWidgets
    customer = customer + 1 #counts total customers for all orders

    start = str(input("Would you like to buy more widgets, y or n: ")) #restart loop or not?
    print('') #prints blank line for formatting

#exit loop

###################Counter Print Statements###################
# takes stores values above and prints formatted output of
# running totals
#
print('Customer Amount: ' + str(customer))
print('Loyalty Members: ' + str(loyaltyMember))
print('Total Widgets ordered: ' + str(totalWidgets))
print('Average Price per Widget: $%1.2f' %averageWidgets)
print('Final Subtotal: $%1.2f' %finalSub)
print('Final Tax Due: $%1.2f' %finalTax)
print('Final Due: $%1.2f' %finalTotal)


